-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2013 at 12:13 PM
-- Server version: 5.1.61
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `BannedIPs`
--

CREATE TABLE IF NOT EXISTS `BannedIPs` (
  `IP` text COLLATE latin1_general_ci NOT NULL,
  `Reason` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `BannedIPs`
--

INSERT INTO `BannedIPs` (`IP`, `Reason`) VALUES
('127.0.0.1', 'Hacking our webhost :P');

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE IF NOT EXISTS `logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` text COLLATE latin1_general_ci NOT NULL,
  `account` text COLLATE latin1_general_ci NOT NULL,
  `success` text COLLATE latin1_general_ci NOT NULL,
  `trap` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `moves`
--

CREATE TABLE IF NOT EXISTS `moves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `power` int(11) NOT NULL,
  `accuracy` int(11) NOT NULL,
  `atk_type` text COLLATE latin1_general_ci NOT NULL,
  `phy_spec` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `moves`
--

INSERT INTO `moves` (`id`, `name`, `power`, `accuracy`, `atk_type`, `phy_spec`) VALUES
(0, 'Tackle', 50, 100, '', 0),
(1, 'Pound', 40, 100, 'Normal', 0),
(2, 'Karate Chop', 50, 100, 'Fighting', 0),
(3, 'Double Slap', 15, 85, 'Normal', 0),
(4, 'Comet Punch', 18, 85, 'Normal', 0),
(5, 'Mega Punch', 80, 85, 'Normal', 0),
(6, 'Payday', 40, 100, 'Normal', 0),
(7, 'Fire Punch', 75, 100, 'Fire', 0),
(8, 'Ice Punch', 75, 100, 'Ice', 0),
(9, 'Thunder Punch', 75, 100, 'Electric', 0),
(10, 'Scratch', 40, 100, 'Normal', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pokedex`
--

CREATE TABLE IF NOT EXISTS `pokedex` (
  `id` int(11) NOT NULL,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `type1` text COLLATE latin1_general_ci NOT NULL,
  `type2` text COLLATE latin1_general_ci NOT NULL,
  `hp` int(11) NOT NULL DEFAULT '1',
  `attack` int(11) NOT NULL DEFAULT '1',
  `defense` int(11) NOT NULL DEFAULT '1',
  `Special_Attack` int(11) NOT NULL DEFAULT '1',
  `Special_Defense` int(11) NOT NULL DEFAULT '1',
  `Speed` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `pokedex`
--

INSERT INTO `pokedex` (`id`, `name`, `type1`, `type2`, `hp`, `attack`, `defense`, `Special_Attack`, `Special_Defense`, `Speed`) VALUES
(498, 'Tepig', 'Fire', '', 65, 1, 1, 1, 1, 1),
(1, 'Bulbasaur', 'Grass', 'Poison', 45, 1, 1, 1, 1, 1),
(4, 'Charmander', 'Fire', '', 39, 1, 1, 1, 1, 1),
(7, 'Squirtle', 'Water', '', 44, 1, 1, 1, 1, 1),
(152, 'Chikorita', 'Grass', '', 45, 1, 1, 1, 1, 1),
(155, 'Cyndaquil', 'Fire', '', 39, 1, 1, 1, 1, 1),
(158, 'Totodile', 'Water', '', 50, 1, 1, 1, 1, 1),
(252, 'Treecko', 'Grass', '', 40, 1, 1, 1, 1, 1),
(255, 'Torchic', 'Fire', '', 45, 1, 1, 1, 1, 1),
(258, 'Mudkip', 'Water', '', 50, 1, 1, 1, 1, 1),
(387, 'Turtwig', 'Grass', '', 55, 1, 1, 1, 1, 1),
(390, 'Chimchar', 'Fire', '', 44, 1, 1, 1, 1, 1),
(393, 'Piplup', 'Water', '', 53, 1, 1, 1, 1, 1),
(495, 'Snivy', 'Grass', '', 45, 1, 1, 1, 1, 1),
(501, 'Oshawott', 'Water', '', 55, 1, 1, 1, 1, 1),
(25, 'Pikachu', 'Electric', '', 35, 55, 30, 50, 40, 90);

-- --------------------------------------------------------

--
-- Table structure for table `pokemon`
--

CREATE TABLE IF NOT EXISTS `pokemon` (
  `pokemon_id` int(255) NOT NULL AUTO_INCREMENT,
  `pokedex_id` int(11) NOT NULL,
  `owner_id` int(255) NOT NULL,
  `nickname` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `slot` int(11) NOT NULL,
  `type` int(255) NOT NULL DEFAULT '1',
  `experience` int(255) NOT NULL DEFAULT '125',
  `level` int(255) NOT NULL DEFAULT '5',
  `move_slot_1` int(11) NOT NULL DEFAULT '0',
  `move_slot_2` int(11) NOT NULL DEFAULT '0',
  `move_slot_3` int(11) NOT NULL DEFAULT '0',
  `move_slot_4` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pokemon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `promos`
--

CREATE TABLE IF NOT EXISTS `promos` (
  `promo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `type_name` text COLLATE latin1_general_ci NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '1',
  `pokedex_id` int(11) NOT NULL,
  PRIMARY KEY (`promo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `promo_log`
--

CREATE TABLE IF NOT EXISTS `promo_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE latin1_general_ci NOT NULL,
  `promo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `security_log`
--

CREATE TABLE IF NOT EXISTS `security_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Event` text COLLATE latin1_general_ci NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`) VALUES
(1, 'normal'),
(2, 'shiny');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` text COLLATE latin1_general_ci NOT NULL,
  `password` text COLLATE latin1_general_ci NOT NULL,
  `Email` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `avatar` longtext COLLATE latin1_general_ci NOT NULL,
  `Rank` text COLLATE latin1_general_ci NOT NULL,
  `Money` int(11) NOT NULL DEFAULT '20000',
  `Coins` int(11) NOT NULL DEFAULT '1000',
  `MGP` int(11) NOT NULL DEFAULT '0',
  `Poke1` int(11) NOT NULL,
  `Poke2` int(11) NOT NULL,
  `Poke3` int(11) NOT NULL,
  `Poke4` int(11) NOT NULL,
  `Poke5` int(11) NOT NULL,
  `Poke6` int(11) NOT NULL,
  `IP` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `password` (`password`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
